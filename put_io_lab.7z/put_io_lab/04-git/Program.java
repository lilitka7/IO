//KOMENTARZ
public class Program {
  public static void main(String[] args){
    System.out.print("Hello World");//KOMENTARZ
  }
}//KOMENTARZ
//komentarz1
//komentarz2